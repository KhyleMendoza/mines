let balance = 50;
let bet = 0;
let gameStarted = false;
let gameOver = false;
let currentWinnings = 0;
const bombIndex = Math.floor(Math.random() * 25);
const grid = document.querySelector('.grid');
const cashoutButton = document.querySelector('#cashout');
const playButton = document.querySelector('#play');

cashoutButton.style.display = 'none';
for (let i = 0; i < 25; i++) {
    const cell = document.createElement('div');
    cell.classList.add('cell', 'hidden');
    const content = document.createElement('span');
    if (i === bombIndex) {
        cell.classList.add('bomb');
        content.textContent = '💣';
    } else {
        cell.classList.add('money');
        content.textContent = '💰';
    }
    cell.appendChild(content);
    cell.addEventListener('click', () => {
    if (gameStarted && !gameOver && cell.classList.contains('hidden')) {
        cell.classList.remove('hidden');
        cashoutButton.style.display = 'inline-block';
        updateCellsLeft();
    if (cell.classList.contains('bomb')) {
        gameOver = true;
        cashoutButton.style.display = 'none';
        document.querySelector('#winnings-container').style.display = 'none';
        document.querySelector('#cells-left-container').style.display = 'none';
        currentWinnings = 0;
        updateWinnings();
        playButton.style.display = 'inline-block';
        const allCells = document.querySelectorAll('.cell');
        allCells.forEach(cell => {
        if (cell.classList.contains('hidden')) {
            cell.classList.remove('hidden');
        if (cell.classList.contains('bomb') || cell.classList.contains('money')) {
            cell.style.backgroundColor = 'gray';
        }

        }
        });
        if (gameOver) {
            document.querySelector('#bet').disabled = false;
            document.querySelector('#num-bombs').disabled = false;
        }
    } else {
        currentWinnings += bet * 2;
        updateWinnings();
        const moneyCells = document.querySelectorAll('.cell.money');
        const hiddenMoneyCells = document.querySelectorAll('.cell.money.hidden');
        if (hiddenMoneyCells.length === 0) {
            balance += currentWinnings;
            currentWinnings = 0;
            updateBalance();
            updateWinnings();
            cashoutButton.style.display = 'none';
            gameOver = true;
            playButton.style.display = 'inline-block';
            document.querySelector('#cells-left-container').style.display = 'none';
            document.querySelector('#bet').disabled = false;
            document.querySelector('#num-bombs').disabled = false;
        }
    }
    }
    });
    grid.appendChild(cell);
}
document.querySelector('#play').addEventListener('click', () => {
    gameStarted = true;
    gameOver = false;
    currentWinnings = 0;
    updateWinnings();
    document.querySelector('#winnings-container').style.display = 'block';
    document.querySelector('#cells-left-container').style.display = 'none';
    document.querySelector('#bet').disabled = true;
    document.querySelector('#num-bombs').disabled = true;
    playButton.style.display = 'none';
    updateCellsLeft();
    const cells = document.querySelectorAll('.cell');
    cells.forEach(cell => {
        cell.classList.add('hidden');
        cell.classList.remove('bomb', 'money');
        cell.style.backgroundColor = '';
        cell.removeChild(cell.firstChild);
    });

    const numBombs = parseInt(document.querySelector('#num-bombs').value);
    const bombIndices = [];
    while (bombIndices.length < numBombs) {
        const newBombIndex = Math.floor(Math.random() * 25);
        if (!bombIndices.includes(newBombIndex)) {
            bombIndices.push(newBombIndex);
        }
    }
    for (let i = 0; i < cells.length; i++) {
        const cell = cells[i];
        const content = document.createElement('span');
        if (bombIndices.includes(i)) {
            cell.classList.add('bomb');
            content.textContent = '💣';
        } else {
            cell.classList.add('money');
            content.textContent = '💰';
        }
        cell.appendChild(content);
    }

    bet = parseFloat(document.querySelector('#bet').value);
    if (bet > balance) {
        alert('You do not have enough balance to make this bet.');
        return;
    }
    balance -= bet;
    updateBalance();
});

cashoutButton.addEventListener('click', () => {
    balance += currentWinnings;
    currentWinnings = 0;
    updateBalance();
    updateWinnings();
    cashoutButton.style.display = 'none';
    gameOver = true;
    playButton.style.display = 'inline-block';
    document.querySelector('#cells-left-container').style.display = 'none';
    document.querySelector('#bet').disabled = false;
    document.querySelector('#num-bombs').disabled = false;
});
function updateBalance() {
    document.querySelector('#balance').textContent = balance.toFixed(2);
}
function updateWinnings() {
    document.querySelector('#winnings').textContent = currentWinnings.toFixed(2);
}

function updateCellsLeft() {
    const hiddenBombCells = document.querySelectorAll('.cell.bomb.hidden');
    const hiddenMoneyCells = document.querySelectorAll('.cell.money.hidden');
    document.querySelector('#bombs-left').textContent = hiddenBombCells.length;
    document.querySelector('#money-left').textContent = hiddenMoneyCells.length;
    document.querySelector('#cells-left-container').style.display = 'block';
}